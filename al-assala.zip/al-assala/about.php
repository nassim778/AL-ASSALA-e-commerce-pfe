<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

include 'includes/header.php';
?>

<div class="main-wrapper">
    <?php include 'includes/aside.php'; ?>
    <main class="main-content">
        <div class="container py-5">
            <!-- Hero Section -->
            <div class="row mb-5">
                <div class="col-md-12 text-center">
                    <h1 class="display-4 text-primary-custom">About AL ASSALA</h1>
                    <p class="lead">Preserving Tunisian Heritage Through Traditional Pottery</p>
                </div>
            </div>
            
            <!-- Story Section -->
            <div class="row align-items-center mb-5">
                <div class="col-md-6">
                    <img src="logo.png" alt=" our logo" class="img-fluid rounded shadow">
                </div>
                <div class="col-md-6">
                    <h2 class="section-title">Our Story</h2>
                    <p>AL ASSALA was founded with a passion for preserving and sharing the rich cultural heritage of Tunisian pottery and crafts. Our journey began with a simple mission: to bring the authentic beauty of traditional Tunisian artistry to homes around the world.</p>
                    <p>Each piece in our collection tells a unique story, crafted by skilled artisans who have inherited generations of knowledge and techniques. We work directly with local craftsmen to ensure fair trade practices and to support the continuation of this timeless art form.</p>
                </div>
            </div>
            
            <!-- Values Section -->
            <div class="row mb-5">
                <div class="col-md-12 text-center mb-4">
                    <h2 class="section-title">Our Values</h2>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-heart fa-3x text-primary-custom mb-3"></i>
                            <h4>Authenticity</h4>
                            <p>We ensure every piece maintains the authentic character of traditional Tunisian craftsmanship.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-hands-helping fa-3x text-primary-custom mb-3"></i>
                            <h4>Fair Trade</h4>
                            <p>We believe in supporting our artisans through fair compensation and sustainable practices.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-star fa-3x text-primary-custom mb-3"></i>
                            <h4>Quality</h4>
                            <p>Each piece is carefully selected to meet our high standards of craftsmanship and durability.</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Artisans Section -->
            <div class="row align-items-center mb-5">
                <div class="col-md-6 order-md-2">
                    <img src="assets/images/shop.jpg" alt="Our shop" class="img-fluid rounded shadow">
                </div>
                <div class="col-md-6 order-md-1">
                    <h2 class="section-title">Our Shop</h2>
                    <p>Behind every piece of pottery is a skilled artisan with years of experience and dedication to their craft. Our artisans use traditional techniques passed down through generations, ensuring that each piece carries the authentic spirit of Tunisian craftsmanship.</p>
                    <p>We take pride in working closely with our artisans, providing them with fair wages and supporting their communities. This partnership allows us to maintain the highest quality standards while preserving traditional pottery-making techniques.</p>
                </div>
            </div>
            
            <!-- Stats Section -->
            <div class="row bg-light-custom py-5 rounded mb-5">
                <div class="col-md-3 text-center mb-3">
                    <h3 class="text-primary-custom">50+</h3>
                    <p>Artisan Partners</p>
                </div>
                <div class="col-md-3 text-center mb-3">
                    <h3 class="text-primary-custom">1000+</h3>
                    <p>Unique Products</p>
                </div>
                <div class="col-md-3 text-center mb-3">
                    <h3 class="text-primary-custom">20+</h3>
                    <p>Years Experience</p>
                </div>
                <div class="col-md-3 text-center mb-3">
                    <h3 class="text-primary-custom">5000+</h3>
                    <p>Happy Customers</p>
                </div>
            </div>
            
            <!-- Call to Action -->
            <div class="row">
                <div class="col-md-12 text-center">
                    <h2 class="section-title">Experience Tunisian Craftsmanship</h2>
                    <p class="mb-4">Discover our collection of handcrafted pottery and bring a piece of Tunisian heritage into your home.</p>
                    <a href="shop.php" class="btn btn-primary btn-lg">Shop Now</a>
                </div>
            </div>
        </div>
    </main>
</div>

<?php include 'includes/footer.php'; ?> 