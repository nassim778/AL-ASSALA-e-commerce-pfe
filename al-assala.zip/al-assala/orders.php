<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

$db = getDB();

// Get user's orders
$stmt = $db->prepare("
    SELECT * FROM orders 
    WHERE member_id = ? 
    ORDER BY created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$orders = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="main-wrapper">
    <?php include 'includes/aside.php'; ?>
    <main class="main-content">
        <div class="container py-5">
            <h1 class="mb-4">My Orders</h1>
            
            <?php if (empty($orders)): ?>
                <div class="alert alert-info">
                    You haven't placed any orders yet.
                </div>
            <?php else: ?>
                <?php foreach ($orders as $order): ?>
                    <div class="card mb-4">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h2>Order #<?php echo $order['id']; ?></h2>
                            <span class="badge bg-<?php 
                                echo $order['status'] === 'pending' ? 'warning' : 
                                    ($order['status'] === 'accepted' ? 'success' : 'danger'); 
                            ?>">
                                <?php echo ucfirst($order['status']); ?>
                            </span>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-8">
                                    <!-- Order Items -->
                                    <?php
                                    $stmt = $db->prepare("
                                        SELECT oi.*, p.name as product_name, p.price as product_price 
                                        FROM order_items oi 
                                        JOIN produit p ON oi.product_id = p.id 
                                        WHERE oi.order_id = ?
                                    ");
                                    $stmt->execute([$order['id']]);
                                    $order_items = $stmt->fetchAll();
                                    ?>
                                    
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>Product</th>
                                                    <th>Price</th>
                                                    <th>Quantity</th>
                                                    <th>Total</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($order_items as $item): ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                                        <td><?php echo number_format($item['product_price'], 2); ?> TND</td>
                                                        <td><?php echo $item['quantity']; ?></td>
                                                        <td><?php echo number_format($item['quantity'] * $item['product_price'], 2); ?> TND</td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th colspan="3">Total</th>
                                                    <th><?php echo number_format($order['total_price'], 2); ?> TND</th>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <!-- Order Status and Messages -->
                                    <div class="card">
                                        <div class="card-header">
                                            <h3>Order Status</h3>
                                        </div>
                                        <div class="card-body">
                                            <p><strong>Status:</strong> <?php echo ucfirst($order['status']); ?></p>
                                            <?php if ($order['delivery_date']): ?>
                                                <p><strong>Delivery Date:</strong> <?php echo date('Y-m-d', strtotime($order['delivery_date'])); ?></p>
                                            <?php endif; ?>
                                            
                                            <!-- Order Messages -->
                                            <?php
                                            $stmt = $db->prepare("
                                                SELECT * FROM order_messages 
                                                WHERE order_id = ? 
                                                ORDER BY created_at DESC
                                            ");
                                            $stmt->execute([$order['id']]);
                                            $messages = $stmt->fetchAll();
                                            
                                            if (!empty($messages)): ?>
                                                <hr>
                                                <h4>Messages</h4>
                                                <?php foreach ($messages as $message): ?>
                                                    <div class="message mb-3">
                                                        <p class="mb-1"><?php echo nl2br(htmlspecialchars($message['message'])); ?></p>
                                                        <small class="text-muted">
                                                            <?php echo date('Y-m-d H:i', strtotime($message['created_at'])); ?>
                                                        </small>
                                                    </div>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </main>
</div>

<?php include 'includes/footer.php'; ?> 