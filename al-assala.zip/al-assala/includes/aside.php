<?php
// aside.php
if (isLoggedIn()): 
    // Determine if we're in the admin directory
    $isAdminPage = strpos($_SERVER['PHP_SELF'], '/admin/') !== false;
    $basePath = $isAdminPage ? '../' : '';

    // Get categories for the filter
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM categories ORDER BY name");
    $stmt->execute();
    $categories = $stmt->fetchAll();

    // Get current category from URL if set
    $current_category = isset($_GET['category']) ? intval($_GET['category']) : null;
?>
<aside class="aside-menu">
    <div class="aside-header">
        <h2>Dashboard</h2>
        <button id="closeAside" class="btn btn-link">
            <i class="fas fa-times"></i>
        </button>
    </div>
    <div class="aside-content">
        <ul class="nav flex-column">
            <?php if (isAdmin()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo $basePath; ?>admin/dashboard.php">
                        <i class="fas fa-tachometer-alt"></i> Admin Dashboard
                    </a>
                </li>
            <?php endif; ?>
            
            <li class="nav-item">
                <a class="nav-link" href="<?php echo $basePath; ?>homepage.php">
                    <i class="fas fa-home"></i> Home
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo $basePath; ?>shop.php">
                    <i class="fas fa-shopping-bag"></i> Shop
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo $basePath; ?>cart.php">
                    <i class="fas fa-shopping-cart"></i> My Cart
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo $basePath; ?>orders.php">
                    <i class="fas fa-box"></i> My Orders
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo $basePath; ?>inbox.php">
                    <i class="fas fa-envelope"></i> Messages
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo $basePath; ?>profile.php">
                    <i class="fas fa-user"></i> My Profile
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo $basePath; ?>contact.php">
                    <i class="fas fa-phone"></i> Contact Us
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo $basePath; ?>about.php">
                    <i class="fas fa-info-circle"></i> About Us
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo $basePath; ?>logout.php">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </li>
        </ul>

        <!-- Categories Section -->
        <div class="categories-section mt-4">
            <h5 class="px-3 mb-3">Categories</h5>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link <?php echo !$current_category ? 'active' : ''; ?>" 
                       href="<?php echo $basePath; ?>shop.php">
                        <i class="fas fa-th-large"></i> All Products
                    </a>
                </li>
                <?php foreach ($categories as $category): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_category == $category['id'] ? 'active' : ''; ?>" 
                           href="<?php echo $basePath; ?>shop.php?category=<?php echo $category['id']; ?>">
                            <i class="fas fa-tag"></i> <?php echo htmlspecialchars($category['name']); ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</aside>

<style>
.aside-menu {
    width: 250px;
    height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    background: #fff;
    box-shadow: 2px 0 5px rgba(0,0,0,0.1);
    z-index: 1000;
    transition: left 0.3s ease;
}

.aside-header {
    padding: 1rem;
    border-bottom: 1px solid #eee;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.aside-content {
    padding: 1rem;
    height: calc(100vh - 60px);
    overflow-y: auto;
}

.nav-link {
    color: #333;
    padding: 0.5rem 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    border-radius: 4px;
    transition: all 0.2s ease;
}

.nav-link:hover {
    background:rgb(251, 250, 250);
    color: #0d6efd;
}

.nav-link.active {
    background:rgba(250, 249, 249, 0.92);
    color: #0d6efd;
}

.nav-link i {
    width: 20px;
    text-align: center;
}

.categories-section {
    border-top: 1px solid #eee;
    padding-top: 1rem;
}

.categories-section h5 {
    color: #666;
    font-size: 0.9rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

@media (max-width: 768px) {
    .aside-menu {
        left: -280px;
    }
    
    .aside-menu.active {
        left: 0;
    }
}
</style>

<script>
document.getElementById('closeAside').addEventListener('click', function() {
    document.querySelector('.aside-menu').classList.remove('active');
});
</script>
<?php endif; ?>

