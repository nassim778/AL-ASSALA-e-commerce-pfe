<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'al_assala');

// Application configuration
define('SITE_NAME', 'AL ASSALA');
define('SITE_URL', 'http://localhost/al-assala');
define('UPLOAD_DIR', __DIR__ . '/../assets/images/products/');

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Error reporting (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1); 