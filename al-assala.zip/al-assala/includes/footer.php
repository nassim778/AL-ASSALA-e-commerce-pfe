    </div><!-- /.container -->

    <footer class="bg-dark text-light mt-5 py-4">
        <script>
(function(){if(!window.chatbase||window.chatbase("getState")!=="initialized"){window.chatbase=(...arguments)=>{if(!window.chatbase.q){window.chatbase.q=[]}window.chatbase.q.push(arguments)};window.chatbase=new Proxy(window.chatbase,{get(target,prop){if(prop==="q"){return target.q}return(...args)=>target(prop,...args)}})}const onLoad=function(){const script=document.createElement("script");script.src="https://www.chatbase.co/embed.min.js";script.id="ejJcnyka7_6U8Ugsx-Wh2";script.domain="www.chatbase.co";document.body.appendChild(script)};if(document.readyState==="complete"){onLoad()}else{window.addEventListener("load",onLoad)}})();
</script>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>About AL ASSALA</h5>
                    <p>Discover the beauty of traditional Tunisian pottery and crafts.</p>
                </div>
                <div class="col-md-4">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="shop.php" class="text-light">Shop</a></li>
                        <li><a href="about.php" class="text-light">About Us</a></li>
                        <li><a href="contact.php" class="text-light">Contact</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Contact Info</h5>
                    <ul class="list-unstyled">
                        <li>Email: alassala@gmail.com</li>
                        <li>Phone: +216 29 676 787</li>
                        <li>Address: Tunisia</li>
                    </ul>
                </div>
            </div>
            <hr class="mt-4">
            <div class="text-center">
                <p>&copy; <?php echo date('Y'); ?> AL ASSALA. All rights reserved.</p>
            </div>
        </div>
    </footer>

    
    <script src="assets/js/main.js"></script>
</body>
</html> 