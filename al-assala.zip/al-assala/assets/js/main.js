// Wait for the DOM to be fully loaded
document.addEventListener("DOMContentLoaded", function () {
  // Initialize tooltips
  var tooltipTriggerList = [].slice.call(
    document.querySelectorAll('[data-bs-toggle="tooltip"]')
  );
  var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
  });

  // Initialize popovers
  var popoverTriggerList = [].slice.call(
    document.querySelectorAll('[data-bs-toggle="popover"]')
  );
  var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
    return new bootstrap.Popover(popoverTriggerEl);
  });

  // Auto-hide alerts after 5 seconds
  setTimeout(function () {
    var alerts = document.querySelectorAll(".alert");
    alerts.forEach(function (alert) {
      var bsAlert = new bootstrap.Alert(alert);
      bsAlert.close();
    });
  }, 5000);

  // Form validation
  var forms = document.querySelectorAll(".needs-validation");
  Array.prototype.slice.call(forms).forEach(function (form) {
    form.addEventListener(
      "submit",
      function (event) {
        if (!form.checkValidity()) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add("was-validated");
      },
      false
    );
  });

  // Image preview for file inputs
  var imageInputs = document.querySelectorAll(".image-input");
  imageInputs.forEach(function (input) {
    input.addEventListener("change", function (e) {
      var preview = document.querySelector(input.dataset.preview);
      if (preview) {
        var file = e.target.files[0];
        var reader = new FileReader();

        reader.onload = function (e) {
          preview.src = e.target.result;
        };

        if (file) {
          reader.readAsDataURL(file);
        }
      }
    });
  });

  // Quantity input controls
  var quantityInputs = document.querySelectorAll(".quantity-input");
  quantityInputs.forEach(function (input) {
    var decrementBtn = input.parentElement.querySelector(".decrement");
    var incrementBtn = input.parentElement.querySelector(".increment");

    if (decrementBtn && incrementBtn) {
      decrementBtn.addEventListener("click", function () {
        var value = parseInt(input.value);
        if (value > 1) {
          input.value = value - 1;
          input.dispatchEvent(new Event("change"));
        }
      });

      incrementBtn.addEventListener("click", function () {
        var value = parseInt(input.value);
        var max = input.getAttribute("max");
        if (!max || value < parseInt(max)) {
          input.value = value + 1;
          input.dispatchEvent(new Event("change"));
        }
      });
    }
  });
});
