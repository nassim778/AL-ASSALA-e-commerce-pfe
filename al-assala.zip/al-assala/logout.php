<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Destroy all session data
session_destroy();

// Redirect to home page with success message
setFlashMessage('success', 'You have been successfully logged out.');
redirect('index.php'); 