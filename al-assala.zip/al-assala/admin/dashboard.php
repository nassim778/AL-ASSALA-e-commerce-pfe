<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Check if user is admin
if (!isAdmin()) {
    redirect('../login.php');
}

$db = getDB();

// Get pending orders
$stmt = $db->prepare("
    SELECT o.*, m.name as customer_name, m.email as customer_email 
    FROM orders o 
    JOIN member m ON o.member_id = m.id 
    WHERE o.status = 'pending' 
    ORDER BY o.created_at DESC
");
$stmt->execute();
$pending_orders = $stmt->fetchAll();

// Get all products
$stmt = $db->prepare("
    SELECT p.*, c.name as category_name 
    FROM produit p 
    LEFT JOIN categories c ON p.category_id = c.id 
    ORDER BY p.created_at DESC
");
$stmt->execute();
$products = $stmt->fetchAll();

// Get all categories
$stmt = $db->prepare("SELECT * FROM categories ORDER BY name");
$stmt->execute();
$categories = $stmt->fetchAll();

include '../includes/header.php';
?>

<div class="main-wrapper">
    <?php include '../includes/aside.php'; ?>
    <main class="main-content">
        <div class="container py-5">
            <h1 class="mb-4">Admin Dashboard</h1>

            <!-- Pending Orders Section -->
            <div class="card mb-4">
                <div class="card-header">
                    <h2>Pending Orders</h2>
                </div>
                <div class="card-body">
                    <?php if (empty($pending_orders)): ?>
                        <p>No pending orders</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Customer</th>
                                        <th>Total</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($pending_orders as $order): ?>
                                        <tr>
                                            <td><?php echo $order['id']; ?></td>
                                            <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
                                            <td><?php echo number_format($order['total_price'], 2); ?> TND</td>
                                            <td><?php echo date('Y-m-d H:i', strtotime($order['created_at'])); ?></td>
                                            <td>
                                                <a href="order_details.php?id=<?php echo $order['id']; ?>" 
                                                   class="btn btn-sm btn-primary">View Details</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Products Management -->
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h2>Products</h2>
                    <a href="add_product.php" class="btn btn-primary">Add New Product</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Price</th>
                                    <th>Stock</th>
                                    <th>Category</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($products as $product): ?>
                                    <tr>
                                        <td><?php echo $product['id']; ?></td>
                                        <td><?php echo htmlspecialchars($product['name']); ?></td>
                                        <td><?php echo number_format($product['price'], 2); ?> TND</td>
                                        <td><?php echo $product['stock']; ?></td>
                                        <td><?php echo htmlspecialchars($product['category_name'] ?? 'Uncategorized'); ?></td>
                                        <td>
                                            <a href="edit_product.php?id=<?php echo $product['id']; ?>" 
                                               class="btn btn-sm btn-warning">Edit</a>
                                            <a href="delete_product.php?id=<?php echo $product['id']; ?>" 
                                               class="btn btn-sm btn-danger"
                                               onclick="return confirm('Are you sure you want to delete this product?')">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Categories Management -->
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h2>Categories</h2>
                    <a href="add_category.php" class="btn btn-primary">Add New Category</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($categories as $category): ?>
                                    <tr>
                                        <td><?php echo $category['id']; ?></td>
                                        <td><?php echo htmlspecialchars($category['name']); ?></td>
                                        <td>
                                            <a href="edit_category.php?id=<?php echo $category['id']; ?>" 
                                               class="btn btn-sm btn-warning">Edit</a>
                                            <a href="delete_category.php?id=<?php echo $category['id']; ?>" 
                                               class="btn btn-sm btn-danger"
                                               onclick="return confirm('Are you sure you want to delete this category?')">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<?php include '../includes/footer.php'; ?> 