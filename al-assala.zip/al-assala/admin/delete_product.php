<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Check if user is admin
if (!isAdmin()) {
    redirect('../login.php');
}

$db = getDB();

// Get product details
$stmt = $db->prepare("SELECT * FROM produit WHERE id = ?");
$stmt->execute([intval($_GET['id'])]);
$product = $stmt->fetch();

if (!$product) {
    redirect('dashboard.php');
}

// Handle deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Delete product
        $stmt = $db->prepare("DELETE FROM produit WHERE id = ?");
        $stmt->execute([$product['id']]);
        
        setFlashMessage('success', 'Product deleted successfully!');
        redirect('admin/dashboard.php');
        
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

include '../includes/header.php';
?>

<div class="main-wrapper">
    <?php include '../includes/aside.php'; ?>
    <main class="main-content">
        <div class="container py-5">
            <h1 class="mb-4">Delete Product</h1>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-body">
                    <p>Are you sure you want to delete the following product?</p>
                    
                    <div class="mb-4">
                        <h4><?php echo htmlspecialchars($product['name']); ?></h4>
                        <p>Price: $<?php echo number_format($product['price'], 2); ?></p>
                        <p>Stock: <?php echo $product['stock']; ?></p>
                    </div>
                    
                    <form method="POST">
                        <button type="submit" class="btn btn-danger">Delete Product</button>
                        <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </main>
</div>

<?php include '../includes/footer.php'; ?> 