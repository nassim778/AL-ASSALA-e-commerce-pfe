<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Check if user is admin
if (!isAdmin()) {
    redirect('../login.php');
}

$db = getDB();

// Get product details
$stmt = $db->prepare("SELECT * FROM produit WHERE id = ?");
$stmt->execute([intval($_GET['id'])]);
$product = $stmt->fetch();

if (!$product) {
    redirect('dashboard.php');
}

// Get all categories
$stmt = $db->prepare("SELECT * FROM categories ORDER BY name");
$stmt->execute();
$categories = $stmt->fetchAll();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $name = sanitize($_POST['name']);
        $price = floatval($_POST['price']);
        $stock = intval($_POST['stock']);
        $category_id = intval($_POST['category_id']);
        $description = sanitize($_POST['description']);
        
        // Handle image upload
        $image = $product['image'];
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $image = uploadImage($_FILES['image']);
        }
        
        // Update product
        $stmt = $db->prepare("
            UPDATE produit 
            SET name = ?, price = ?, stock = ?, category_id = ?, description = ?, image = ?
            WHERE id = ?
        ");
        $stmt->execute([$name, $price, $stock, $category_id, $description, $image, $product['id']]);
        
        setFlashMessage('success', 'Product updated successfully!');
        redirect('admin/dashboard.php');
        
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

include '../includes/header.php';
?>

<div class="main-wrapper">
    <?php include '../includes/aside.php'; ?>
    <main class="main-content">
        <div class="container py-5">
            <h1 class="mb-4">Edit Product</h1>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-body">
                    <form method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($product['name']); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Price</label>
                            <input type="number" name="price" class="form-control" step="0.01" value="<?php echo $product['price']; ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Stock</label>
                            <input type="number" name="stock" class="form-control" value="<?php echo $product['stock']; ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Category</label>
                            <select name="category_id" class="form-select" required>
                                <option value="">Select Category</option>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?php echo $category['id']; ?>" <?php echo $category['id'] == $product['category_id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($category['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea name="description" class="form-control" rows="3"><?php echo htmlspecialchars($product['description']); ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Current Image</label>
                            <?php if ($product['image']): ?>
                                <img src="../assets/images/products/<?php echo htmlspecialchars($product['image']); ?>" 
                                     class="img-thumbnail mb-2" 
                                     style="max-width: 200px;">
                            <?php endif; ?>
                            <input type="file" name="image" class="form-control" accept="image/*">
                            <small class="text-muted">Leave empty to keep current image</small>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Update Product</button>
                        <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </main>
</div>

<?php include '../includes/footer.php'; ?> 