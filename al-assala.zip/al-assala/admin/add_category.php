<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Check if user is admin
if (!isAdmin()) {
    redirect('../login.php');
}

$db = getDB();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $name = sanitize($_POST['name']);
        
        // Insert category
        $stmt = $db->prepare("
            INSERT INTO categories (name, created_at, updated_at) 
            VALUES (?, NOW(), NOW())
        ");
        $stmt->execute([$name]);
        
        setFlashMessage('success', 'Category added successfully!');
        redirect('admin/dashboard.php');
        
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

include '../includes/header.php';
?>

<div class="main-wrapper">
    <?php include '../includes/aside.php'; ?>
    <main class="main-content">
        <div class="container py-5">
            <h1 class="mb-4">Add New Category</h1>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Add Category</button>
                        <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </main>
</div>

<?php include '../includes/footer.php'; ?> 