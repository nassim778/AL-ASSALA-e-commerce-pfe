<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Check if user is admin
if (!isAdmin()) {
    redirect('../login.php');
}

$db = getDB();

// Get order details
$stmt = $db->prepare("
    SELECT o.*, m.name as customer_name, m.email as customer_email 
    FROM orders o 
    JOIN member m ON o.member_id = m.id 
    WHERE o.id = ?
");
$stmt->execute([$_GET['id']]);
$order = $stmt->fetch();

if (!$order) {
    redirect('dashboard.php');
}

// Get order items
$stmt = $db->prepare("
    SELECT oi.*, p.name as product_name, p.price as product_price 
    FROM order_items oi 
    JOIN produit p ON oi.product_id = p.id 
    WHERE oi.order_id = ?
");
$stmt->execute([$order['id']]);
$order_items = $stmt->fetchAll();

// Handle order status update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = $_POST['status'];
    $delivery_date = $_POST['delivery_date'];
    $message = $_POST['message'];
    
    // Update order status
    $stmt = $db->prepare("UPDATE orders SET status = ?, delivery_date = ? WHERE id = ?");
    $stmt->execute([$status, $delivery_date, $order['id']]);
    
    // Add message to order_messages
    $stmt = $db->prepare("
        INSERT INTO order_messages (order_id, message, created_at) 
        VALUES (?, ?, NOW())
    ");
    $stmt->execute([$order['id'], $message]);
    
    // Redirect back to dashboard
    redirect('admin/dashboard.php');
}

include '../includes/header.php';
?>

<div class="main-wrapper">
    <?php include '../includes/aside.php'; ?>
    <main class="main-content">
        <div class="container py-5">
            <h1 class="mb-4">Order Details #<?php echo $order['id']; ?></h1>
            
            <div class="row">
                <div class="col-md-8">
                    <!-- Order Items -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h2>Order Items</h2>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>Price</th>
                                            <th>Quantity</th>
                                            <th>Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($order_items as $item): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                                <td><?php echo number_format($item['product_price'], 2); ?> TND</td>
                                                <td><?php echo $item['quantity']; ?></td>
                                                <td><?php echo number_format($item['quantity'] * $item['product_price'], 2); ?> TND</td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th colspan="3">Total</th>
                                            <th><?php echo number_format($order['total_price'], 2); ?> TND</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <!-- Order Status -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h2>Order Status</h2>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <div class="mb-3">
                                    <label class="form-label">Current Status</label>
                                    <p class="form-control-static">
                                        <span class="badge bg-<?php 
                                            echo $order['status'] === 'pending' ? 'warning' : 
                                                ($order['status'] === 'accepted' ? 'success' : 'danger'); 
                                        ?>">
                                            <?php echo ucfirst($order['status']); ?>
                                        </span>
                                    </p>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Update Status</label>
                                    <select name="status" class="form-select" required>
                                        <option value="accepted">Accept</option>
                                        <option value="rejected">Reject</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Delivery Date (if accepted)</label>
                                    <input type="date" name="delivery_date" class="form-control" 
                                           min="<?php echo date('Y-m-d'); ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Message to Customer</label>
                                    <textarea name="message" class="form-control" rows="3" required></textarea>
                                </div>
                                
                                <button type="submit" class="btn btn-primary">Update Order</button>
                            </form>
                        </div>
                    </div>
                    
                    <!-- Customer Information -->
                    <div class="card">
                        <div class="card-header">
                            <h2>Customer Information</h2>
                        </div>
                        <div class="card-body">
                            <p><strong>Name:</strong> <?php echo htmlspecialchars($order['customer_name']); ?></p>
                            <p><strong>Email:</strong> <?php echo htmlspecialchars($order['customer_email']); ?></p>
                            <p><strong>Order Date:</strong> <?php echo date('Y-m-d H:i', strtotime($order['created_at'])); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<?php include '../includes/footer.php'; ?> 