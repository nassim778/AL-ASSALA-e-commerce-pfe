# AL ASSALA E-commerce Website

An e-commerce platform for traditional Tunisian pottery and crafts.

## Project Structure
```
al-assala/
├── assets/
│   ├── css/
│   ├── js/
│   └── images/
├── includes/
│   ├── config.php
│   ├── db.php
│   └── functions.php
├── index.php
├── login.php
├── signup.php
├── shop.php
├── contact.php
├── about.php
├── homepage.php
├── dashboard.php
├── profile.php
└── payment.php
```

## Setup Instructions

1. Install WAMP Server
2. Clone this repository to your `www` directory
3. Import the database schema from `database/al_assala.sql`
4. Configure database connection in `includes/config.php`
5. Access the website through `http://localhost/al-assala`

## Technologies Used
- Frontend: HTML, CSS, JavaScript
- Backend: PHP
- Database: MySQL (via WAMP)

## Features
- User authentication (login/signup)
- Product catalog
- Admin dashboard
- User profiles
- Contact form
- Basic payment simulation 