<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';
$db = getDB();

// Handle adding to cart

if (isset($_POST['add_to_cart'])) 
{
    if (isLoggedIn()) {
    $product_id = intval($_POST['product_id']);
    $quantity = intval($_POST['quantity']);
    
    // Initialize cart if not exists
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    // Add or update item in cart
    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id] += $quantity;
    } else {
        $_SESSION['cart'][$product_id] = $quantity;
    }
    
    setFlashMessage('success', 'Product added to cart successfully!');
    redirect('shop.php');}
    
    else {
    setFlashMessage('error','You need to login first!');
    redirect('login.php');
    }
}




// Handle product detail view
if (isset($_GET['product'])) {
    $stmt = $db->prepare("SELECT * FROM produit WHERE id = ?");
    $stmt->execute([intval($_GET['product'])]);
    $product = $stmt->fetch();
    
    if ($product) {
        include 'includes/header.php';
        ?>
        <div class="main-wrapper">
            <?php include 'includes/aside.php'; ?>
            <main class="main-content">
                <div class="container py-5">
                    <div class="row">
                        <div class="col-md-6">
                            <img src="assets/images/products/<?php echo htmlspecialchars($product['image']); ?>" 
                                 class="img-fluid rounded" 
                                 alt="<?php echo htmlspecialchars($product['name']); ?>">
                        </div>
                        <div class="col-md-6">
                            <h1 class="mb-4"><?php echo htmlspecialchars($product['name']); ?></h1>
                            <p class="h3 text-primary-custom mb-4">$<?php echo number_format($product['price'], 2); ?></p>
                            
                            <?php if ($product['description']): ?>
                                <div class="mb-4">
                                    <h4>Description</h4>
                                    <p><?php echo nl2br(htmlspecialchars($product['description'])); ?></p>
                                </div>
                            <?php endif; ?>
                            
                            <div class="mb-4">
                                <h4>Stock</h4>
                                <p><?php echo $product['stock'] > 0 ? 'In Stock (' . $product['stock'] . ' available)' : 'Out of Stock'; ?></p>
                            </div>
                            
                            <?php if ($product['stock'] > 0): ?>
                                <form action="shop.php" method="POST" class="mb-4">
                                    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                    <div class="input-group mb-3" style="max-width: 200px;">
                                        <button class="btn btn-outline-secondary decrement" type="button">-</button>
                                        <input type="number" 
                                               class="form-control text-center quantity-input" 
                                               name="quantity" 
                                               value="1" 
                                               min="1" 
                                               max="<?php echo $product['stock']; ?>">
                                        <button class="btn btn-outline-secondary increment" type="button">+</button>
                                    </div>
                                    <button type="submit" name="add_to_cart" class="btn-primary">Add to Cart</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </main>
        </div>
        <?php
        
        exit;
    }
}

// Get current category from URL
$current_category = isset($_GET['category']) ? intval($_GET['category']) : null;

// Get products with category filter
$sql = "SELECT p.*, c.name as category_name 
        FROM produit p 
        LEFT JOIN categories c ON p.category_id = c.id";
$params = [];

if ($current_category) {
    $sql .= " WHERE p.category_id = ?";
    $params[] = $current_category;
}

$sql .= " ORDER BY p.name";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

include 'includes/header.php';
?>
<div class="main-wrapper">
    <?php include 'includes/aside.php'; ?>
    <main class="main-content">
        <div class="container py-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>Shop</h1>
                <button class="btn btn-primary d-md-none" id="toggleAside">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            
            <?php if ($current_category): ?>
                <div class="alert alert-info">
                    Showing products in category: <?php echo htmlspecialchars($products[0]['category_name'] ?? 'Unknown'); ?>
                    <a href="shop.php" class="float-end">Show all products</a>
                </div>
            <?php endif; ?>
            
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                <?php foreach ($products as $product): ?>
                    <div class="col">
                        <div class="card h-100">
                            <?php if ($product['image']): ?>
                                <img src="assets/images/products/<?php echo htmlspecialchars($product['image']); ?>" 
                                     class="card-img-top" 
                                     alt="<?php echo htmlspecialchars($product['name']); ?>"
                                     style="height: 200px; object-fit: cover;">
                            <?php endif; ?>
                            
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($product['name']); ?></h5>
                                <?php if ($product['category_name']): ?>
                                    <span class="badge bg-secondary mb-2"><?php echo htmlspecialchars($product['category_name']); ?></span>
                                <?php endif; ?>
                                <p class="card-text"><?php echo htmlspecialchars($product['description']); ?></p>
                                <p class="card-text">
                                    <strong>Price: <?php echo number_format($product['price'], 2); ?> TND</strong>
                                </p>
                                <p class="card-text">
                                    <small class="text-muted">
                                        Stock: <?php echo $product['stock']; ?> units
                                    </small>
                                </p>
                                
                                <?php if ($product['stock'] > 0): ?>
                                    <form method="POST" action="shop.php">
                                        <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                        <div class="input-group mb-3">
                                            <input type="number" 
                                                   name="quantity" 
                                                   class="form-control" 
                                                   value="1" 
                                                   min="1" 
                                                   max="<?php echo $product['stock']; ?>"
                                                   required>
                                            <button type="submit" name="add_to_cart" class="btn btn-primary">Add to Cart</button>
                                        </div>
                                    </form>
                                <?php else: ?>
                                    <button class="btn btn-secondary" disabled>Out of Stock</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </main>
</div>

<script>
document.getElementById('toggleAside').addEventListener('click', function() {
    document.querySelector('.aside-menu').classList.toggle('active');
});

// Add quantity increment/decrement functionality
document.querySelectorAll('.increment').forEach(button => {
    button.addEventListener('click', function() {
        const input = this.parentElement.querySelector('.quantity-input');
        const max = parseInt(input.getAttribute('max'));
        const currentValue = parseInt(input.value);
        if (currentValue < max) {
            input.value = currentValue + 1;
        }
    });
});

document.querySelectorAll('.decrement').forEach(button => {
    button.addEventListener('click', function() {
        const input = this.parentElement.querySelector('.quantity-input');
        const currentValue = parseInt(input.value);
        if (currentValue > 1) {
            input.value = currentValue - 1;
        }
    });
});
</script>

<?php include 'includes/footer.php'; ?> 