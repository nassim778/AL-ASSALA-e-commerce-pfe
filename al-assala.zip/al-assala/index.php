<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

// Get featured products
$db = getDB();
$stmt = $db->prepare("SELECT * FROM produit ORDER BY RAND() LIMIT 6");
$stmt->execute();
$featured_products = $stmt->fetchAll();

include 'includes/header.php';
?>

<!-- Hero Section -->
<section class="hero-section text-center">
    <div class="container">
        <h1 class="display-4 text-primary-custom">Welcome to AL ASSALA</h1>
        <p class="lead">Discover the Beauty of Traditional Tunisian Pottery</p>
        <img src="logo.png" alt="AL ASSALA" style="width: 150px; height: 150px;"><br>
        <br>
        <a href="shop.php" class="btn btn-primary btn-lg">Shop Now</a>
    </div>
</section>

<!-- Featured Products -->
<section class="py-5">
    <div class="container">
        <h2 class="section-title text-center">Featured Products</h2>
        <div class="product-grid">
            <?php foreach ($featured_products as $product): ?>
                <div class="card product-card fade-in">
                    <img src="assets/images/products/<?php echo htmlspecialchars($product['image']); ?>" 
                         class="card-img-top" 
                         alt="<?php echo htmlspecialchars($product['name']); ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($product['name']); ?></h5>
                        <p class="card-text text-primary-custom"><?php echo number_format($product['price'], 2); ?> TND</p>
                        <a href="shop.php?product=<?php echo $product['id']; ?>" class="btn btn-primary">View Details</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="py-5 bg-light-custom">
    <div class="container">
        <div class="row text-center">
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <div class="card-body">
                        <i class="fas fa-shipping-fast fa-3x mb-3 text-primary-custom"></i>
                        <h4>Fast Shipping</h4>
                        <p>Quick delivery to your doorstep</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <div class="card-body">
                        <i class="fas fa-certificate fa-3x mb-3 text-primary-custom"></i>
                        <h4>Authentic Crafts</h4>
                        <p>100% handmade by skilled artisans</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <div class="card-body">
                        <i class="fas fa-lock fa-3x mb-3 text-primary-custom"></i>
                        <h4>Secure Payment</h4>
                        <p>Safe and encrypted transactions</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- About Section -->
<section class="py-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h2 class="section-title">About AL ASSALA</h2>
                <p>Discover the rich heritage of Tunisian pottery through our carefully curated collection. Each piece tells a story of tradition, craftsmanship, and cultural excellence.</p>
                <a href="about.php" class="btn btn-primary">Learn More</a>
            </div>
            <div class="col-md-6">
                <img src="assets/images/about-image.jpg" alt="Traditional Tunisian Pottery" class="img-fluid rounded">
            </div>
        </div>
    </div>
</section>

<!-- Newsletter Section -->
<section class="py-5 bg-light-custom">
    <div class="container">
        <div class="row justify-content-center text-center">
            <div class="col-md-8">
                <h3 class="section-title">Stay Updated</h3>
                <p>Subscribe to our newsletter for the latest products and Tunisian craft news.</p>
                <form class="row g-3 justify-content-center">
                    <div class="col-auto">
                        <input type="email" class="form-control" placeholder="Enter your email">
                    </div>
                    <div class="col-auto">
                        <button type="submit" class="btn btn-primary">Subscribe</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?> 