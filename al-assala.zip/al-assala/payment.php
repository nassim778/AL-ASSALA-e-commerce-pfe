<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

$db = getDB();

// Get cart items from session
$cart = $_SESSION['cart'] ?? [];

if (empty($cart)) {
    redirect('shop.php');
}

// Calculate total
$total = 0;
$items = [];

foreach ($cart as $product_id => $quantity) {
    $stmt = $db->prepare("SELECT * FROM produit WHERE id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch();
    
    if ($product) {
        $items[] = [
            'id' => $product['id'],
            'name' => $product['name'],
            'price' => $product['price'],
            'quantity' => $quantity,
            'total' => $product['price'] * $quantity
        ];
        $total += $product['price'] * $quantity;
    }
}

// Handle order submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $db->beginTransaction();
        
        // Create order
        $stmt = $db->prepare("
            INSERT INTO orders (member_id, total_price, status, created_at) 
            VALUES (?, ?, 'pending', NOW())
        ");
        $stmt->execute([$_SESSION['user_id'], $total]);
        $order_id = $db->lastInsertId();
        
        // Add order items
        $stmt = $db->prepare("
            INSERT INTO order_items (order_id, product_id, quantity, price) 
            VALUES (?, ?, ?, ?)
        ");
        
        foreach ($items as $item) {
            $stmt->execute([
                $order_id,
                $item['id'],
                $item['quantity'],
                $item['price']
            ]);
            
            // Update product stock
            $stmt2 = $db->prepare("
                UPDATE produit 
                SET stock = stock - ? 
                WHERE id = ?
            ");
            $stmt2->execute([$item['quantity'], $item['id']]);
        }
        
        $db->commit();
        
        // Clear cart
        unset($_SESSION['cart']);
        
        // Redirect to orders page
        redirect('orders.php');
        
    } catch (Exception $e) {
        $db->rollBack();
        $error = "An error occurred while processing your order. Please try again.";
    }
}

include 'includes/header.php';
?>

<div class="main-wrapper">
    <?php include 'includes/aside.php'; ?>
    <main class="main-content">
        <div class="container py-5">
            <h1 class="mb-4">Order Summary</h1>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <div class="row">
                <div class="col-md-8">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h2>Order Items</h2>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>Price</th>
                                            <th>Quantity</th>
                                            <th>Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($items as $item): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($item['name']); ?></td>
                                                <td><?php echo number_format($item['price'], 2); ?> TND</td>
                                                <td><?php echo $item['quantity']; ?></td>
                                                <td><?php echo number_format($item['total'], 2); ?> TND</td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th colspan="3">Total</th>
                                            <th><?php echo number_format($total, 2); ?> TND</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h2>Submit Order</h2>
                        </div>
                        <div class="card-body">
                            <p>Please review your order before submitting. Once submitted, our team will review your order and get back to you with the delivery details.</p>
                            
                            <form method="POST">
                                <button type="submit" class="btn btn-primary btn-lg w-100">
                                    Submit Order
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<?php include 'includes/footer.php'; ?> 