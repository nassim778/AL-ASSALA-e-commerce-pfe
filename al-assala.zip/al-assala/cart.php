<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

$db = getDB();

// Handle remove from cart
if (isset($_POST['remove_item'])) {
    $product_id = intval($_POST['product_id']);
    if (isset($_SESSION['cart'][$product_id])) {
        unset($_SESSION['cart'][$product_id]);
        setFlashMessage('success', 'Item removed from cart successfully!');
        redirect('cart.php');
    }
}

// Handle update quantity
if (isset($_POST['update_quantity'])) {
    $product_id = intval($_POST['product_id']);
    $quantity = intval($_POST['quantity']);
    
    if ($quantity > 0) {
        $_SESSION['cart'][$product_id] = $quantity;
        setFlashMessage('success', 'Cart updated successfully!');
    } else {
        unset($_SESSION['cart'][$product_id]);
        setFlashMessage('success', 'Item removed from cart successfully!');
    }
    redirect('cart.php');
}

// Get cart items with product details
$cart_items = [];
$total = 0;

if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $product_id => $quantity) {
        $stmt = $db->prepare("SELECT * FROM produit WHERE id = ?");
        $stmt->execute([$product_id]);
        $product = $stmt->fetch();
        
        if ($product) {
            $item_total = $product['price'] * $quantity;
            $total += $item_total;
            
            $cart_items[] = [
                'id' => $product['id'],
                'name' => $product['name'],
                'price' => $product['price'],
                'quantity' => $quantity,
                'total' => $item_total,
                'stock' => $product['stock']
            ];
        }
    }
}

include 'includes/header.php';
?>

<div class="main-wrapper">
    <?php include 'includes/aside.php'; ?>
    <main class="main-content">
        <div class="container py-5">
            <h1 class="mb-4">Shopping Cart</h1>
            
            <?php if (empty($cart_items)): ?>
                <div class="alert alert-info">
                    Your cart is empty. <a href="shop.php">Continue shopping</a>
                </div>
            <?php else: ?>
                <div class="row">
                    <div class="col-md-8">
                        <div class="card mb-4">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Product</th>
                                                <th>Price</th>
                                                <th>Quantity</th>
                                                <th>Total</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($cart_items as $item): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                                                    <td><?php echo number_format($item['price'], 2); ?> TND</td>
                                                    <td>
                                                        <form method="POST" class="d-inline">
                                                            <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                                            <div class="input-group" style="max-width: 150px;">
                                                                <input type="number" 
                                                                       class="form-control" 
                                                                       name="quantity" 
                                                                       value="<?php echo $item['quantity']; ?>"
                                                                       min="1" 
                                                                       max="<?php echo $item['stock']; ?>">
                                                                <button type="submit" name="update_quantity" class="btn btn-outline-secondary">
                                                                    Update
                                                                </button>
                                                            </div>
                                                        </form>
                                                    </td>
                                                    <td><?php echo number_format($item['total'], 2); ?> TND</td>
                                                    <td>
                                                        <form method="POST" class="d-inline">
                                                            <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                                            <button type="submit" name="remove_item" class="btn btn-danger btn-sm">
                                                                Remove
                                                            </button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="card-title">Order Summary</h3>
                                <div class="d-flex justify-content-between mb-3">
                                    <span>Subtotal:</span>
                                    <span><?php echo number_format($total, 2); ?> TND</span>
                                </div>
                                <hr>
                                <div class="d-flex justify-content-between mb-3">
                                    <strong>Total:</strong>
                                    <strong><?php echo number_format($total, 2); ?> TND</strong>
                                </div>
                                
                                <div class="d-grid gap-2">
                                    <a href="shop.php" class="btn btn-outline-primary">Continue Shopping</a>
                                    <a href="payment.php" class="btn btn-primary">Proceed to Checkout</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>

<?php include 'includes/footer.php'; ?> 