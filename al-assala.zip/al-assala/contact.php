<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name']);
    $email = sanitize($_POST['email']);
    $subject = sanitize($_POST['subject']);
    $message = sanitize($_POST['message']);
    
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $error = 'Please fill in all fields';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address';
    } else {
        try {
            $db = getDB();
            
            // Get admin user
            $stmt = $db->prepare("SELECT id FROM member WHERE is_admin = 1 LIMIT 1");
            $stmt->execute();
            $admin = $stmt->fetch();
            
            if ($admin) {
                // If user is logged in, use their ID, otherwise create a temporary user
                $sender_id = isLoggedIn() ? $_SESSION['user_id'] : null;
                
                if (!$sender_id) {
                    // Create a temporary user for non-logged in users
                    $stmt = $db->prepare("
                        INSERT INTO member (name, email, is_admin, created_at) 
                        VALUES (?, ?, 0, NOW())
                    ");
                    $stmt->execute([$name, $email]);
                    $sender_id = $db->lastInsertId();
                }
                
                // Insert message
                $stmt = $db->prepare("
                    INSERT INTO messages (sender_id, receiver_id, subject, message) 
                    VALUES (?, ?, ?, ?)
                ");
                $stmt->execute([$sender_id, $admin['id'], $subject, $message]);
                
                $success = 'Thank you for your message. We will get back to you soon!';
                $_POST = array(); // Clear form
            } else {
                $error = 'Unable to process your message. Please try again later.';
            }
        } catch (Exception $e) {
            $error = 'An error occurred. Please try again later.';
        }
    }
}

include 'includes/header.php';
?>

<div class="main-wrapper">
    <?php include 'includes/aside.php'; ?>
    <main class="main-content">
        <div class="container py-5">
            <h1>Contact Us</h1>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <div class="card shadow">
                <div class="card-body p-5">
                    <div class="row mb-5">
                        <div class="col-md-4 text-center mb-3">
                            <i class="fas fa-map-marker-alt fa-2x text-primary-custom mb-3"></i>
                            <h5>Address</h5>
                            <p>Tunisia</p>
                        </div>
                        <div class="col-md-4 text-center mb-3">
                            <i class="fas fa-phone fa-2x text-primary-custom mb-3"></i>
                            <h5>Phone</h5>
                            <p>+216 XX XXX XXX</p>
                        </div>
                        <div class="col-md-4 text-center mb-3">
                            <i class="fas fa-envelope fa-2x text-primary-custom mb-3"></i>
                            <h5>Email</h5>
                            <p>info@alassala.com</p>
                        </div>
                    </div>
                    
                    <form method="POST" action="contact.php" class="needs-validation" novalidate>
                        <div class="mb-3">
                            <label for="name" class="form-label">Your Name</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="name" 
                                   name="name" 
                                   value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>"
                                   required>
                            <div class="invalid-feedback">
                                Please enter your name.
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email Address</label>
                            <input type="email" 
                                   class="form-control" 
                                   id="email" 
                                   name="email" 
                                   value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>"
                                   required>
                            <div class="invalid-feedback">
                                Please enter a valid email address.
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="subject" class="form-label">Subject</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="subject" 
                                   name="subject" 
                                   value="<?php echo isset($_POST['subject']) ? htmlspecialchars($_POST['subject']) : ''; ?>"
                                   required>
                            <div class="invalid-feedback">
                                Please enter a subject.
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="message" class="form-label">Message</label>
                            <textarea class="form-control" 
                                      id="message" 
                                      name="message" 
                                      rows="5" 
                                      required><?php echo isset($_POST['message']) ? htmlspecialchars($_POST['message']) : ''; ?></textarea>
                            <div class="invalid-feedback">
                                Please enter your message.
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Send Message</button>
                    </form>
                </div>
            </div>
            
            <!-- Map Section -->
            <div class="row mt-5">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body p-0">
                            <!-- Replace with actual map embed code in production -->
                           <h2>Our Location : </h2>
                  <iframe
                    
                    src="https://www.openstreetmap.org/export/embed.html?bbox=8.993701%2C33.426742%2C9.033701%2C33.486742&layer=mapnik&marker=33.456742%2C9.013701"
                    style="border: 1px solid #ddd; display: inline-block;">
                  </iframe>
                  <br/>
                  <small style="display: inline-block; margin-top: 5px;">
                    <a href="https://www.openstreetmap.org/?mlat=33.456742&mlon=9.013701#map=15/33.456742/9.013701" target="_blank">
                      View Larger Map
                    </a>
                  </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<?php include 'includes/footer.php'; ?> 