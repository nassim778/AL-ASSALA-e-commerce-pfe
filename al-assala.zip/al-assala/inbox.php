<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

$db = getDB();
$user_id = $_SESSION['user_id'];
$is_admin = isAdmin();

// Handle conversation deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_conversation']) && $is_admin) {
    $other_user_id = intval($_POST['other_user_id']);
    try {
        $db->beginTransaction();
        
        // Delete all messages in the conversation
        $stmt = $db->prepare("
            DELETE FROM messages 
            WHERE (sender_id = ? AND receiver_id = ?)
               OR (sender_id = ? AND receiver_id = ?)
        ");
        $stmt->execute([$user_id, $other_user_id, $other_user_id, $user_id]);
        
        $db->commit();
        setFlashMessage('success', 'Conversation deleted successfully!');
        redirect('inbox.php');
    } catch (Exception $e) {
        $db->rollBack();
        $error = 'Failed to delete conversation. Please try again.';
    }
}

// Get user's conversations
$stmt = $db->prepare("
    SELECT DISTINCT 
        CASE 
            WHEN m.sender_id = ? THEN m.receiver_id 
            ELSE m.sender_id 
        END as other_user_id,
        u.name as other_user_name,
        u.is_admin as other_user_is_admin,
        MAX(m.created_at) as last_message_date
    FROM messages m
    JOIN member u ON (
        CASE 
            WHEN m.sender_id = ? THEN m.receiver_id 
            ELSE m.sender_id 
        END = u.id
    )
    WHERE m.sender_id = ? OR m.receiver_id = ?
    GROUP BY other_user_id, other_user_name, other_user_is_admin
    ORDER BY last_message_date DESC
");
$stmt->execute([$user_id, $user_id, $user_id, $user_id]);
$conversations = $stmt->fetchAll();

// Get selected conversation
$selected_user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : null;
$messages = [];
$other_user = null;

if ($selected_user_id) {
    // Get messages with selected user
    $stmt = $db->prepare("
        SELECT m.*, u.name as sender_name, u.is_admin as sender_is_admin
        FROM messages m
        JOIN member u ON m.sender_id = u.id
        WHERE (m.sender_id = ? AND m.receiver_id = ?)
           OR (m.sender_id = ? AND m.receiver_id = ?)
        ORDER BY m.created_at ASC
    ");
    $stmt->execute([$user_id, $selected_user_id, $selected_user_id, $user_id]);
    $messages = $stmt->fetchAll();
    
    // Mark messages as read
    $stmt = $db->prepare("
        UPDATE messages 
        SET is_read = TRUE 
        WHERE receiver_id = ? AND sender_id = ? AND is_read = FALSE
    ");
    $stmt->execute([$user_id, $selected_user_id]);
    
    // Get other user details
    $stmt = $db->prepare("SELECT * FROM member WHERE id = ?");
    $stmt->execute([$selected_user_id]);
    $other_user = $stmt->fetch();
}

// Handle new message
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message']) && $selected_user_id) {
    $message = sanitize($_POST['message']);
    if (!empty($message)) {
        $stmt = $db->prepare("
            INSERT INTO messages (sender_id, receiver_id, message, created_at) 
            VALUES (?, ?, ?, NOW())
        ");
        $stmt->execute([$user_id, $selected_user_id, $message]);
        redirect("inbox.php?user_id=" . $selected_user_id);
    }
}

include 'includes/header.php';
?>

<div class="main-wrapper">
    <?php include 'includes/aside.php'; ?>
    <main class="main-content">
        <div class="container py-5">
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <div class="row">
                <!-- Conversations List -->
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Conversations</h5>
                        </div>
                        <div class="list-group list-group-flush">
                            <?php if (empty($conversations)): ?>
                                <div class="list-group-item">
                                    <p class="text-muted mb-0">No conversations yet</p>
                                </div>
                            <?php else: ?>
                                <?php foreach ($conversations as $conv): ?>
                                    <div class="list-group-item <?php echo $selected_user_id == $conv['other_user_id'] ? 'active' : ''; ?>">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <a href="?user_id=<?php echo $conv['other_user_id']; ?>" class="text-decoration-none flex-grow-1">
                                                <div class="d-flex w-100 justify-content-between">
                                                    <h6 class="mb-1">
                                                        <?php echo htmlspecialchars($conv['other_user_name']); ?>
                                                        <?php if ($conv['other_user_is_admin'] == 1): ?>
                                                            <span class="badge bg-primary">Admin</span>
                                                        <?php endif; ?>
                                                    </h6>
                                                    <small><?php echo date('M j, g:i a', strtotime($conv['last_message_date'])); ?></small>
                                                </div>
                                            </a>
                                            <?php if ($is_admin): ?>
                                                <form method="POST" class="ms-2" onsubmit="return confirm('Are you sure you want to delete this conversation?');">
                                                    <input type="hidden" name="other_user_id" value="<?php echo $conv['other_user_id']; ?>">
                                                    <button type="submit" name="delete_conversation" class="btn btn-sm btn-danger">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Messages Area -->
                <div class="col-md-8">
                    <?php if ($selected_user_id): ?>
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">
                                    Conversation with <?php echo htmlspecialchars($other_user['name']); ?>
                                    <?php if ($other_user['is_admin'] == 1): ?>
                                        <span class="badge bg-primary">Admin</span>
                                    <?php endif; ?>
                                </h5>
                                <?php if ($is_admin): ?>
                                    <form method="POST" onsubmit="return confirm('Are you sure you want to delete this conversation?');">
                                        <input type="hidden" name="other_user_id" value="<?php echo $selected_user_id; ?>">
                                        <button type="submit" name="delete_conversation" class="btn btn-danger btn-sm">
                                            <i class="fas fa-trash"></i> Delete Conversation
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                            <div class="card-body">
                                <div class="messages-container" style="height: 400px; overflow-y: auto;">
                                    <?php foreach ($messages as $message): ?>
                                        <div class="message <?php echo $message['sender_id'] == $user_id ? 'sent' : 'received'; ?> mb-3">
                                            <div class="message-content p-3 rounded <?php echo $message['sender_id'] == $user_id ? 'bg-primary text-white' : 'bg-light'; ?>">
                                                <p class="mb-0"><?php echo nl2br(htmlspecialchars($message['message'])); ?></p>
                                                <small class="text-muted d-block mt-1">
                                                    <?php echo date('g:i a', strtotime($message['created_at'])); ?>
                                                </small>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                
                                <form method="POST" class="mt-3">
                                    <div class="input-group">
                                        <input type="text" name="message" class="form-control" placeholder="Type your message..." required>
                                        <button type="submit" class="btn btn-primary">Send</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="card">
                            <div class="card-body text-center">
                                <p class="text-muted mb-0">Select a conversation or start a new one</p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
</div>

<style>
.message {
    max-width: 80%;
}
.message.sent {
    margin-left: auto;
}
.message.received {
    margin-right: auto;
}
</style>

<?php include 'includes/footer.php'; ?> 