<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

// Get user information
$db = getDB();
$stmt = $db->prepare("SELECT * FROM member WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

// Get recent products
$stmt = $db->prepare("SELECT * FROM produit ORDER BY created_at DESC LIMIT 4");
$stmt->execute();
$recent_products = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="main-wrapper">
    <?php include 'includes/aside.php'; ?>
    <main class="main-content">
        <div class="container py-5">
            <!-- Welcome Section -->
            <div class="row mb-5">
                <div class="col-md-12">
                    <div class="card bg-light-custom">
                        <div class="card-body">
                            <h2 class="card-title">Welcome back, <?php echo htmlspecialchars($user['name']); ?>!</h2>
                            <p class="card-text">Explore our latest collection of traditional Tunisian pottery and crafts.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="row mb-5">
                <div class="col-md-4 mb-3">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-user fa-3x mb-3 text-primary-custom"></i>
                            <h4>My Profile</h4>
                            <p>Update your personal information</p>
                            <a href="profile.php" class="btn btn-primary">View Profile</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-shopping-cart fa-3x mb-3 text-primary-custom"></i>
                            <h4>Shop Now</h4>
                            <p>Browse our collection</p>
                            <a href="shop.php" class="btn btn-primary">Go to Shop</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-envelope fa-3x mb-3 text-primary-custom"></i>
                            <h4>Contact Us</h4>
                            <p>Need help? Get in touch</p>
                            <a href="contact.php" class="btn btn-primary">Contact</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Products -->
            <div class="row mb-4">
                <div class="col-md-12">
                    <h3 class="section-title">Recently Added Products</h3>
                </div>
            </div>
            
            <div class="row">
                <?php foreach ($recent_products as $product): ?>
                    <div class="col-md-3 mb-4">
                        <div class="card product-card">
                            <img src="assets/images/products/<?php echo htmlspecialchars($product['image']); ?>" 
                                 class="card-img-top" 
                                 alt="<?php echo htmlspecialchars($product['name']); ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($product['name']); ?></h5>
                                <p class="card-text text-primary-custom"><?php echo number_format($product['price'], 2); ?> TND</p>
                                <a href="shop.php?product=<?php echo $product['id']; ?>" class="btn btn-primary">View Details</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Special Offers -->
            <div class="row mt-5">
                <div class="col-md-12">
                    <div class="card bg-light-custom">
                        <div class="card-body text-center">
                            <h3 class="card-title">Special Offer!</h3>
                            <p class="card-text">Get 10% off on your first purchase. Use code: WELCOME10</p>
                            <a href="shop.php" class="btn btn-primary">Shop Now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<?php include 'includes/footer.php'; ?> 