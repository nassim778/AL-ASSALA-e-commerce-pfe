-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 14, 2025 at 04:13 PM
-- Server version: 9.1.0
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `al_assala`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'ZIR', '2025-05-04 19:52:27', '2025-05-04 19:52:27'),
(2, 'JARA', '2025-05-04 19:52:42', '2025-05-04 19:52:42'),
(3, 'ZIR ZIT', '2025-05-04 19:52:57', '2025-05-04 19:52:57'),
(4, 'GOLA', '2025-05-04 20:06:24', '2025-05-04 20:06:24'),
(5, 'vase', '2025-05-05 15:49:44', '2025-05-05 15:49:44'),
(6, 'vase', '2025-05-05 16:01:29', '2025-05-05 16:01:29'),
(7, 'decoration', '2025-05-09 19:13:18', '2025-05-09 19:13:18'),
(8, 'craft', '2025-05-09 19:13:34', '2025-05-09 19:13:34'),
(9, 'wood craft', '2025-05-09 19:13:46', '2025-05-09 19:13:46'),
(10, 'CUP', '2025-05-15 16:41:23', '2025-05-15 16:41:23'),
(11, 'food', '2025-05-15 16:42:22', '2025-05-15 16:42:22');

-- --------------------------------------------------------

--
-- Table structure for table `commande`
--

DROP TABLE IF EXISTS `commande`;
CREATE TABLE IF NOT EXISTS `commande` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_member` int NOT NULL,
  `id_produit` int NOT NULL,
  `prix_total` float NOT NULL,
  `status_commande` tinyint(1) NOT NULL,
  `delivry_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
CREATE TABLE IF NOT EXISTS `member` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_admin` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`id`, `name`, `surname`, `address`, `email`, `password`, `is_admin`, `created_at`, `phone`) VALUES
(1, 'nassim', 'ben salem', 'douz-gbeli', 'nassim@gmail.com', '$2y$10$FgPYgGSzBvA6m0q6HZuCCeqGGywaJf4N7ZHkI6WYbuut0Rx6OYvOS', 1, '2025-04-24 16:26:41', '29676787'),
(2, 'bachir', 'bacha', 'douz', 'bachir@gmail.com', '$2y$10$DJyMTguHAv3oB/dZa99siO4OeRok70/NGsDKBWRHiHFEu6qDnYm2q', 0, '2025-04-30 21:08:00', '96200685'),
(3, 'hossin', 'hossin', 'ghlissia', 'hossin@gmail.com', '123456', 0, '2025-04-30 21:19:31', '99888777'),
(4, 'wissem', ' rached', 'saudi', 'wissem@gmail.com', '$2y$10$ea8c74fPpOq5G6UeuEOZHuo2BjzEgFR1UEu6W0K/hnOrGo6FZVfXu', 0, '2025-04-30 21:22:49', '45555888'),
(5, 'kalono', 'kalani', 'gabes', 'kalani@gmail.com', '$2y$10$30ejpjgZxyDnY2A8qZf4wu01XXDQgYHdtdKDJyEKiRUGo1varrXBW', 0, '2025-05-04 17:50:37', '93222444'),
(6, 'menji', 'karem', 'sfax', 'menji@gmail.com', '$2y$10$cyL7GHnUiuA7OGSe8L7soecIfQ7HKGkSgRwkI6HckncCMBNNm/J5.', 0, '2025-05-05 14:46:35', NULL),
(7, 'ahmed', 'kaoubi', 'douz', 'ahmedkaoubi463@gmail.com', '$2y$10$opQY1BOu0eQPBEAQWX98d.JlrbcT0hqnCCa9.0NTsLPCJi9wB8b4G', 0, '2025-05-28 13:43:14', NULL),
(8, 'Mohamed', 'Belhadj', 'Douz, Kebili', 'mohamedbelhaadj@gmail.com', '$2y$10$DL1OZJIX7R..pLZGNBqH...cpIaTgMxn.xZHVQHOlI6h2TQXtUxiC', 0, '2025-05-29 22:55:48', '54823138'),
(9, 'ali', 'rached', 'douz', 'ali@gmail.com', '$2y$10$JUZIdP5.U41TtwqemHlSGecYtt3f31MGeS9EBXe8UI3X8TI95b2Ji', 0, '2025-05-30 14:03:44', NULL),
(10, 'karim', 'karim', 'karim', 'karim@gmail.com', '123456789', 1, '2025-08-14 16:08:24', '99655445');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sender_id` int NOT NULL,
  `receiver_id` int NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `sender_id` (`sender_id`),
  KEY `receiver_id` (`receiver_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `sender_id`, `receiver_id`, `subject`, `message`, `is_read`, `created_at`) VALUES
(1, 1, 6, 'salem', 'ya weldi wink', 1, '2025-05-05 15:53:35'),
(2, 6, 1, 'salem', 'hmd et toi', 1, '2025-05-05 15:54:44'),
(3, 1, 3, 'hossin', 'wink', 0, '2025-05-05 15:56:51'),
(4, 1, 6, 'cc', 'hmd', 0, '2025-05-05 15:57:09'),
(5, 1, 3, '', 'ahla bik', 0, '2025-05-05 16:36:20'),
(6, 5, 1, 'kalani', 'hallo', 1, '2025-05-05 16:37:26'),
(7, 1, 5, '', 'cv', 1, '2025-05-05 16:37:45'),
(8, 5, 1, '', 'hmd', 1, '2025-05-05 16:38:00'),
(9, 1, 5, '', 'cc', 1, '2025-05-05 21:33:34'),
(10, 1, 6, '', 'cv', 0, '2025-05-05 21:47:23'),
(11, 5, 1, '', '111', 0, '2025-05-14 19:11:55');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `member_id` int NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `status` enum('pending','accepted','rejected') NOT NULL DEFAULT 'pending',
  `delivery_date` date DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `member_id`, `total_price`, `status`, `delivery_date`, `created_at`, `updated_at`) VALUES
(1, 9, 144.00, 'pending', '2025-05-16', '2025-05-04 18:06:16', '2025-05-04 18:06:16'),
(2, 1, 73.00, 'accepted', '2025-05-31', '2025-05-04 19:30:54', '0000-00-00 00:00:00'),
(3, 1, 50.00, 'rejected', '0000-00-00', '2025-05-04 19:35:38', '0000-00-00 00:00:00'),
(4, 5, 189.00, 'accepted', '2025-05-28', '2025-05-05 15:43:41', '0000-00-00 00:00:00'),
(5, 5, 45.00, 'pending', NULL, '2025-05-05 18:02:39', '0000-00-00 00:00:00'),
(6, 1, 210.00, 'pending', NULL, '2025-05-05 22:43:51', '0000-00-00 00:00:00'),
(7, 5, 162.00, 'accepted', '2025-05-22', '2025-05-05 22:44:47', '0000-00-00 00:00:00'),
(8, 5, 1048.00, 'rejected', '2025-05-28', '2025-05-07 21:29:17', '0000-00-00 00:00:00'),
(9, 5, 124.00, 'accepted', '0000-00-00', '2025-05-07 23:04:44', '0000-00-00 00:00:00'),
(10, 5, 172.00, 'accepted', '2025-05-14', '2025-05-08 08:52:01', '0000-00-00 00:00:00'),
(11, 7, 108.00, 'accepted', '2025-05-31', '2025-05-28 14:48:55', '0000-00-00 00:00:00'),
(12, 8, 30.00, 'accepted', '2025-05-30', '2025-05-29 23:58:11', '0000-00-00 00:00:00'),
(13, 5, 235.00, 'accepted', '2025-06-01', '2025-05-30 11:13:09', '0000-00-00 00:00:00'),
(14, 5, 45.00, 'pending', NULL, '2025-05-30 12:01:00', '0000-00-00 00:00:00'),
(15, 9, 188.00, 'accepted', '2025-06-06', '2025-05-30 15:09:25', '0000-00-00 00:00:00'),
(16, 1, 180.00, 'accepted', '2025-06-19', '2025-06-13 20:10:09', '0000-00-00 00:00:00'),
(17, 1, 62.00, 'pending', NULL, '2025-08-14 17:12:59', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
CREATE TABLE IF NOT EXISTS `order_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL,
  `price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`) VALUES
(1, 2, 3, 4, 12.00),
(2, 2, 4, 5, 5.00),
(3, 3, 5, 2, 25.00),
(4, 4, 10, 7, 15.00),
(5, 4, 7, 3, 28.00),
(6, 5, 10, 1, 15.00),
(7, 5, 13, 2, 15.00),
(8, 6, 13, 10, 15.00),
(9, 6, 3, 5, 12.00),
(10, 7, 12, 1, 12.00),
(11, 7, 13, 10, 15.00),
(12, 8, 3, 2, 12.00),
(13, 8, 9, 3, 8.00),
(14, 8, 5, 40, 25.00),
(15, 9, 13, 4, 15.00),
(16, 9, 2, 8, 8.00),
(17, 10, 5, 4, 25.00),
(18, 10, 12, 6, 12.00),
(19, 11, 9, 6, 8.00),
(20, 11, 12, 5, 12.00),
(21, 12, 13, 2, 15.00),
(22, 13, 13, 5, 15.00),
(23, 13, 9, 20, 8.00),
(24, 14, 13, 3, 15.00),
(25, 15, 12, 14, 12.00),
(26, 15, 11, 10, 2.00),
(27, 16, 12, 15, 12.00),
(28, 17, 12, 5, 12.00),
(29, 17, 11, 1, 2.00);

-- --------------------------------------------------------

--
-- Table structure for table `order_messages`
--

DROP TABLE IF EXISTS `order_messages`;
CREATE TABLE IF NOT EXISTS `order_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `message` text NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `order_messages`
--

INSERT INTO `order_messages` (`id`, `order_id`, `message`, `created_at`) VALUES
(6, 9, 'MERCI DE VOTER CONFIENCE', '2025-05-24 23:10:33'),
(3, 3, 'allah 8aleb', '2025-05-04 19:36:57'),
(4, 7, 'vvc,', '2025-05-05 22:45:30'),
(5, 10, 'cv', '2025-05-08 08:54:55'),
(7, 4, 'CC', '2025-05-24 23:15:19'),
(8, 4, 'CC', '2025-05-24 23:15:36'),
(9, 8, 'desolé', '2025-05-24 23:19:53'),
(10, 11, 'mar7ba bik', '2025-05-28 14:52:05'),
(11, 12, 'cv', '2025-05-30 00:00:42'),
(12, 13, 'THANK YOU ', '2025-05-30 11:13:52'),
(13, 15, 'h', '2025-05-30 15:13:20'),
(14, 16, 'mregl', '2025-06-13 20:10:29');

-- --------------------------------------------------------

--
-- Table structure for table `produit`
--

DROP TABLE IF EXISTS `produit`;
CREATE TABLE IF NOT EXISTS `produit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text,
  `stock` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `category_id` int DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_product_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `produit`
--

INSERT INTO `produit` (`id`, `name`, `price`, `image`, `description`, `stock`, `created_at`, `category_id`, `updated_at`) VALUES
(1, 'ZIR', 35.00, 'zir1', 'this zir keep the water healthy fresh', 15, '2025-04-24 16:35:02', 1, NULL),
(2, 'JARA', 8.00, 'jara', 'this item is used like a bottle of water ', 192, '2025-04-24 16:44:43', 0, NULL),
(3, 'GOLA FOR GRILLING', 12.00, 'GOLA LA7AM SE8IRA.jfif\r\n', 'gola for meat roasting', 222, '2025-05-01 13:42:31', 0, NULL),
(4, 'JARA FOR WATER', 5.00, 'jara1.jfif', 'JARA FOR WATER', 40, '2025-05-01 13:42:31', 0, NULL),
(6, 'ZIR FOR OIL', 20.00, 'zir zit 1.jpg', 'ZIR  is for keep oil healthy', 140, '2025-05-01 13:42:31', 0, NULL),
(7, 'SERBIS', 28.00, 'serbis.jfif', 'sebis for table', 42, '2025-05-01 13:42:31', 7, NULL),
(8, 'JARA FOR WATER', 5.00, 'jara water.jfif', 'Jara for water drinking', 48, '2025-05-01 13:42:31', 0, NULL),
(9, 'GOLA FOR GRILLING', 8.00, 'gola la7am moyen.jfif', 'gola for roasting meat', 46, '2025-05-01 13:42:31', 0, NULL),
(10, 'MEDUIM ZIR FOR OIL', 15.00, 'zir zit moyen.jfif', 'zir for keep oil healthy', 67, '2025-05-01 13:42:31', 0, NULL),
(11, 'CUP FOR WATER', 2.00, 'cup water.jfif', 'this cup is for drink water', 189, '2025-05-01 13:42:31', 2, NULL),
(12, 'BENT GOLA', 12.00, 'bentgola.jfif', 'BENT GOLA used for water keeping', 34, '2025-05-01 13:47:16', 4, NULL),
(13, 'DARBOUKA', 15.00, '6818e2a2a5eae.jpg', 'darbouka', 39, '2025-05-04 18:54:24', 6, NULL),
(14, 'pestle', 18.00, '68192ce87ea34.jpg', 'pestle for food', 17, '2025-05-05 21:26:00', 5, NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
